package org.example;

import controller.ApplicationController;

public class Main {
    public static void main(String[] args){
        ApplicationController applicationController = new ApplicationController();
        applicationController.start();
    }
}