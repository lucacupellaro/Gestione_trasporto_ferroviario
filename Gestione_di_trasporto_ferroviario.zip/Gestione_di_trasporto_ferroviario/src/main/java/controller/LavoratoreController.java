package controller;

import exception.DAOException;
import model.dao.*;
import model.domain.*;
import view.AcquirenteHomeScreenView;
import view.GestoreServizioHomeView;
import view.LavoratoreHomeView;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LavoratoreController {
    public void start(){

        try{
            ConnectionFactory.changeRole(Role.LAVORATORI);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }

        lavoratoreOption();

    }

    private void lavoratoreOption(){



        while(true){

            int scelta;

            try {
                scelta = LavoratoreHomeView.showHomeScreen();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            switch(scelta){

                case 1 -> generaReport();
                case 3 -> exit();

            }



        }


    }


    public void generaReport(){

        boolean flag = false;
        List<Orari> orari = null;
        Lavoratore lavoratore;

        LoginController credentials = new LoginController();
        String username=credentials.getLoggedUser();

        GetLavoratoreCFProcedureDao getLavoratoreCFProcedureDao = new GetLavoratoreCFProcedureDao();
        try {
           lavoratore=getLavoratoreCFProcedureDao.execute(username);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }

        GetReportLavoratoreProcedureDAO getReportLavoratoreProcedureDAO = new GetReportLavoratoreProcedureDAO();

        try {
            orari=getReportLavoratoreProcedureDAO.getReport(lavoratore.getCodiceFiscale());
            LavoratoreHomeView lavoratoreHomeView = new LavoratoreHomeView();
            lavoratoreHomeView.generaReport(orari);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }



        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }


    }


    public List<Lavoratore> getLavoratore(int flag,String matricola) throws DAOException {
        GetLavoratoriProcedureDAO getLavoratoriProcedureDAO = new GetLavoratoriProcedureDAO();
        List<Lavoratore> lavoratori = new ArrayList<Lavoratore>();
        if(flag==0){
            lavoratori= getLavoratoriProcedureDAO.getCapotreni();
        }
        if(flag==1){
            lavoratori= getLavoratoriProcedureDAO.getMacchinisti();
        }if(flag==2){
            lavoratori= getLavoratoriProcedureDAO.getMacchinistiTreno(matricola);
        }
        if(flag==3){
            lavoratori= getLavoratoriProcedureDAO.getCapotrenoTreno(matricola);
        }

        return lavoratori;
    }


    private void exit() {
        AcquirenteHomeScreenView.exit();
        System.exit(0);
    }

}
