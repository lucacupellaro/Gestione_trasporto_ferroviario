package controller;

import exception.DAOException;
import model.dao.ConnectionFactory;
import model.dao.RegistraManutenzioneProcedureDao;
import model.dao.RegistraTrattaProcedureDao;
import model.domain.Fermate;
import model.domain.Role;
import model.domain.StoricoManutenzione;
import model.domain.Tratta;
import view.AcquirenteHomeScreenView;
import view.GestoreServizioHomeView;
import view.ManutentoreHomeView;

import java.io.IOException;
import java.sql.SQLException;


public class ManutentoreController {

    public void start(){

        try{
            ConnectionFactory.changeRole(Role.MANUTENTORE);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }

        gestoreOption();

    }

    private void gestoreOption() {



        while(true){

            int scelta;

            try {
                scelta = ManutentoreHomeView.showHomeScreen();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            switch(scelta){

                case 1 -> registraManutenzione();
                case 2 -> exit();

            }



        }


    }

    public void registraManutenzione(){
        Boolean flag = false;
        StoricoManutenzione manutenzione = new StoricoManutenzione();
        ManutentoreHomeView manutentoreHomeView = new ManutentoreHomeView();


        try {
            manutenzione = manutentoreHomeView.manutenzione();
        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }



        try {
            RegistraManutenzioneProcedureDao registraManutenzioneProcedureDao = RegistraManutenzioneProcedureDao.getInstance();
            flag = registraManutenzioneProcedureDao.execute(new Object[]{manutenzione});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }

    private void exit() {
        ManutentoreHomeView.exit();
        System.exit(0);
    }


}
