package controller;


import model.domain.Credentials;

public interface ControllerSession {
    void start(Credentials credentials);
}
