package controller;

import exception.DAOException;
import model.dao.*;
import model.domain.*;
import view.AcquirenteHomeScreenView;
import view.GestoreServizioHomeView;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class GestoreController implements  Controller{

    public void start(){

        try{
            ConnectionFactory.changeRole(Role.GESTORI_DEL_SERVIZIO);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }

        gestoreOption();

    }

    private void gestoreOption() {



        while(true){

            int scelta;

            try {
                scelta = GestoreServizioHomeView.showHomeScreen();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            switch(scelta){

                case 1 -> registraTreno();
                case 2 -> registraVagone();
                case 3 -> registraLocomotrice();
                case 4 -> registraCorsa();
                case 5 -> registraTratta();
                case 6 -> registraFermata();
                case 7 -> exit();

            }



        }


    }





    public void registraTratta(){
        Boolean flag = false;
        Tratta tratta = new Tratta();

        List <Fermate> fermate= new ArrayList<>();
        try {
            fermate = GestoreServizioHomeView.newTratta();
        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }

        tratta.setFermate(fermate);

        try {
            RegistraTrattaProcedureDao registraTrattaProcedureDao = RegistraTrattaProcedureDao.getInstance();
            flag = registraTrattaProcedureDao.execute(new Object[]{tratta});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }





    public List<Fermate> visualizzaTratta() throws DAOException {

        List<Fermate> fermate = new ArrayList<>();
        GetFermateProcedureDao getFermateProcedureDao = new GetFermateProcedureDao();
        fermate =getFermateProcedureDao.getFermate();
        return fermate;

    }



    public void registraTreno(){
        boolean flag = false;
        Treni treno = null;
        Lavoratore macchinista=null;
        Lavoratore capotreno=null;

        try {
            treno = GestoreServizioHomeView.getTrenoInfo();
            macchinista = GestoreServizioHomeView.getMacchinistaInfo();
            capotreno = GestoreServizioHomeView.getCapotrenoInfo();
        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }


        try {
            TrenoRegistrationProcedureDao insertTreno = TrenoRegistrationProcedureDao.getInstance();
            flag = insertTreno.execute(new Object[]{treno,macchinista,capotreno});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }




    public void registraVagone(){
        boolean flag = false;
        Vagone vagone = null;
        Treni treno = null;



        try {
            vagone = GestoreServizioHomeView.getVagoniInfo();
            treno = GestoreServizioHomeView.getTrenoMatricola();


        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }


        try {
            VagoneRegistrationProcedureDao insertVagone = VagoneRegistrationProcedureDao.getInstance();
            flag = insertVagone.execute(new Object[]{vagone,treno});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }

    public List<Treni> getTreniInfo() throws DAOException {
            GetTreniProcedureDAO getTreniProcedureDAO = new GetTreniProcedureDAO();
            List<Treni> treno = new ArrayList<Treni>();
            treno= getTreniProcedureDAO.getTreni();
            return treno;
    }

    public List<Tratta> getTratteInfo() throws DAOException {
        GetTratteProcedureDao getTratteProcedureDao = new GetTratteProcedureDao();
        List<Tratta> tratta = new ArrayList<Tratta>();
        tratta= getTratteProcedureDao.getTratte();

        return tratta;
    }


    public void registraLocomotrice(){
        boolean flag = false;
        Locomotrici locomotrici = null;
        Treni treno = null;



        try {
            locomotrici = GestoreServizioHomeView.getLocomotriciInfo();
            treno = GestoreServizioHomeView.getTrenoMatricola();


        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }


        try {
            LocomotriceRegistrationProcedureDAO insertLocomotrice = LocomotriceRegistrationProcedureDAO.getInstance();
            flag = insertLocomotrice.execute(new Object[]{locomotrici,treno});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }

    public void registraCorsa(){
        boolean flag = false;
        Corsa corsa=null;

        try{
            corsa=GestoreServizioHomeView.registraCorsa();
        }catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }

        try {
            RegistraCorseProcedureDao registraCorse = RegistraCorseProcedureDao.getInstance();
            flag = registraCorse.execute(new Object[]{corsa});
        } catch (DAOException var4) {
            DAOException e = var4;

        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }

    }

    public void registraFermata(){
        boolean flag = false;
        Fermate fermate=null;


        try {
            fermate = GestoreServizioHomeView.getFermateInfo();
        } catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }


        try {
            RegistraFermateProcedureDAO registraFermate = RegistraFermateProcedureDAO.getInstance();
            flag = registraFermate.execute(new Object[]{fermate});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }

        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }
    }


    private void exit() {
        AcquirenteHomeScreenView.exit();
        System.exit(0);
    }

}
