package controller;

import exception.DAOException;
import model.dao.*;
import model.domain.*;
import view.AcquirenteHomeScreenView;
import view.GestoreServizioHomeView;


import java.io.IOException;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.System.exit;


public class AcquirenteController {
    public void start(){

        try{
            ConnectionFactory.changeRole(Role.ACQUIRENTE);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }

        try {
            acquirenteOption();
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }


    }

    private void acquirenteOption() throws DAOException {


        while(true){

            int scelta;

            try {
                scelta = AcquirenteHomeScreenView.showHomeScreen();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            switch (scelta) {
                case 1:
                    this.visualizzaPrenotazioni();
                    break;
                case 2:
                    this.acquistaPrenotazioni();
                    break;
                case 3:
                    this.exit();
            }


        }


    }

    public void visualizzaPrenotazioni()  {
        GetPrenotazioneProcedureDao prenotazione  = new GetPrenotazioneProcedureDao();
        List <Prenotazione> prenotazioni= new ArrayList<>();

        LoginController login = new LoginController();
        String username=login.getLoggedUser();



        try {
            GetAcquirenteCFDao getAcquirenteCFDao = new GetAcquirenteCFDao();
            Acquirente acquirente=getAcquirenteCFDao.execute(username);
            prenotazioni=prenotazione.getPrenotazione(acquirente.getCodiceFiscale());
            AcquirenteHomeScreenView acquirenteHomeScreenView = new AcquirenteHomeScreenView();
            acquirenteHomeScreenView.visualizzaPrenotaioni(prenotazioni);
        }catch (DAOException e){
            throw new RuntimeException(e);

        }



    }



    public void acquistaPrenotazioni() throws DAOException {

        boolean flag = false;
        Corsa corsa=null;
        Time orarioPartenza=null;

        try{
            corsa=AcquirenteHomeScreenView.acquistaPrenotazione();
            orarioPartenza=visualizzaOrari(corsa.getDataCorsa(), corsa.getIdTratta());
        }catch (IOException var5) {
            IOException e = var5;
            //ApplicationView.printError(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }

        LoginController credentials = new LoginController();
        String username=credentials.getLoggedUser();

        GetAcquirenteCFDao acquirenteCFDao = new GetAcquirenteCFDao();
        Acquirente acquirente=acquirenteCFDao.execute(username);


        Prenotazione prenotazione = new Prenotazione(acquirente.getCodiceFiscale(),corsa.getDataCorsa(),orarioPartenza,corsa.getIdTratta());


        try {
            RegistraPrenotazioneProcedureDao insertPrenotazione = RegistraPrenotazioneProcedureDao.getInstance();
            flag = insertPrenotazione.execute(new Object[]{prenotazione});
        } catch (DAOException var4) {
            DAOException e = var4;
            //ApplicationView.printError(e);
        }





        if (flag) {
            System.out.println("");
            System.out.println("Inserimento avvenuto con successo!");
        }else{
            System.out.println("Registrazione non avvenuta");
        }


    }


    public Time  visualizzaOrari(Date data, int idTratta) throws DAOException, IOException {
        GetOrariProcedureDao getOrariProcedureDao = new GetOrariProcedureDao();
        List <Orari> orari= new ArrayList<>();
        orari= getOrariProcedureDao.getOrari(data,idTratta);
        Time orariop=AcquirenteHomeScreenView.visualizzaOrari(orari);
        return orariop;
    }




    public void cancellaPrenotazioni(){
        System.out.println("acquista prenotazioni:");
    }


    private void exit() {
        AcquirenteHomeScreenView.exit();
        System.exit(0);
    }



}
