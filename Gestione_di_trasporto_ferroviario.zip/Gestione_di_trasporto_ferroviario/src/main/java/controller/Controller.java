package controller;

public interface Controller {
    void start();
}
