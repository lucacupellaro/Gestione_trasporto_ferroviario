package view;

import controller.GestoreController;
import exception.DAOException;
import model.domain.StoricoManutenzione;
import model.domain.Treni;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ManutentoreHomeView {
    public static int showHomeScreen() throws IOException {

        System.out.println("sei loggato come Manutentore scegli cosa vuoi fare");

        int choise;
        System.out.println("");
        System.out.println("Benvenuto nella tua home screen!");
        System.out.println("Cosa vuoi fare?");
        System.out.println("1) Aggiungi manutenzione ");
        System.out.println("2) Esci");
        System.out.println("");
        Scanner input = new Scanner(System.in);

        while(true){

            System.out.println("Inserisci il codice: ");
            choise = input.nextInt();
            if(choise >= 1 && choise <= 2){
                break;
            }
            System.out.println("Codice non valido");
        }

        return choise;
    }

    public StoricoManutenzione manutenzione() throws DAOException, IOException {
        System.out.println("Benvenuto in inserisci una nuova manutenzione ");

        StoricoManutenzione storicoManutenzione = new StoricoManutenzione();

        System.out.println("Scegli il treno per cui inserire la manutezione: ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Scegli la matricola del treno che deve compiere questa corsa");
        GestoreController gestoreController = new GestoreController();
        List<Treni> treni = gestoreController.getTreniInfo();

        for (Treni treni_ : treni) {
            System.out.println(treni_.getMatricola());
        }
        String matricola = reader.readLine();
        storicoManutenzione.setTreno(matricola);


        System.out.println("Scegli la data di manutenzione: ");


        java.sql.Date dataManutenzione = null;
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            System.out.println("Inserisci la data in cui è stata fatta la manutenzione: [yyyy-mm-dd]");
            Date date = dateFormat.parse(reader.readLine());
            dataManutenzione = new java.sql.Date(date.getTime());

        } catch (ParseException e) {
            System.out.println("Errore nell'inserimento della data");
            e.printStackTrace();
            System.exit(1);
        }

        storicoManutenzione.setData(dataManutenzione);

        System.out.println("Scegli la descrizione da inserire: ");
        String descrizione = reader.readLine();

        storicoManutenzione.setManutenzione(descrizione);

        return storicoManutenzione;

    }

    public static void exit(){
        System.out.println("");
        System.out.println("A presto!");
    }
}
