package view;

import model.domain.Orari;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class LavoratoreHomeView {
    public static int showHomeScreen() throws IOException {

        System.out.println("sei loggato come lavoratore scegli cosa vuoi fare");

        int choise;
        System.out.println("");
        System.out.println("Benvenuto nella tua home screen!");
        System.out.println("Cosa vuoi fare?");
        System.out.println("1) generare il report dei tuoi turni ");
        System.out.println("2) Esci");
        System.out.println("");
        Scanner input = new Scanner(System.in);

        while(true){

            System.out.println("Inserisci il codice: ");
            choise = input.nextInt();
            if(choise >= 1 && choise <= 5){
                break;
            }
            System.out.println("Codice non valido");
        }

        return choise;
    }


    public static void generaReport(List<Orari> orari){
        System.out.println("");
        System.out.println("Questo è il report dei tuoi turni:");

        for(Orari orari1 : orari){
            System.out.println(orari1.getDataCorsa()+ " " + orari1.getMatricolaTreno()+ " " +orari1.getOrarioPartenza()+ " " +orari1.getOrarioArrivo());
        }
    }

    public static void exit(){
        System.out.println("");
        System.out.println("A presto!");
    }


}
