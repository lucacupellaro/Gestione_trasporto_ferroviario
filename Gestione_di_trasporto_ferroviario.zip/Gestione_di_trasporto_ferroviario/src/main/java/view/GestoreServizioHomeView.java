package view;

import controller.GestoreController;
import controller.LavoratoreController;
import exception.DAOException;
import model.domain.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.*;

public class GestoreServizioHomeView {
    public static int showHomeScreen() throws IOException {

        System.out.println("sei loggato come Gestore scegli cosa vuoi fare");

        int choise;
        System.out.println("");
        System.out.println("Benvenuto nella tua home screen!");
        System.out.println("Cosa vuoi fare?");
        System.out.println("1) Registra Treno ");
        System.out.println("2) Registra vagone");
        System.out.println("3) Registra locomotrice");
        System.out.println("4) Registra Corsa");
        System.out.println("5) Registra Tratta");
        System.out.println("6) Registra fermata");
        System.out.println("7) Esci");
        System.out.println("");
        Scanner input = new Scanner(System.in);

        while(true){

            System.out.println("Inserisci il codice: ");
            choise = input.nextInt();
            if(choise >= 1 && choise <= 7){
                break;
            }
            System.out.println("Codice non valido");
        }

        return choise;
    }

    public static Corsa registraCorsa() throws DAOException, IOException {
        Corsa corsa = new Corsa();
        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Scegli la matricola del treno che deve compiere questa corsa");
        GestoreController gestoreController = new GestoreController();
        List<Treni> treni = gestoreController.getTreniInfo();

        for (Treni treni_ : treni) {
            System.out.println(treni_.getMatricola());
        }
        String matricola = reader.readLine();
        corsa.setmatricolaTreno(matricola);
        System.out.println("Scegli la tratta da compiere");

        List<Tratta> tratte = gestoreController.getTratteInfo();
        Map<Integer, List<String>> tratteMap = new LinkedHashMap<>();
        for (Tratta tratta_ : tratte) {
            tratteMap.computeIfAbsent(tratta_.getId(), k -> new ArrayList<>()).add(tratta_.getStazione());
        }

        int index = 1;
        for (Map.Entry<Integer, List<String>> entry : tratteMap.entrySet()) {
            System.out.printf("%d) %s%n", index, String.join(",", entry.getValue()));
            index++;
        }

        int sceltaTratta = Integer.parseInt(reader.readLine());
        corsa.setIdTratta(sceltaTratta);

        LavoratoreController lavoratoreController = new LavoratoreController();
        System.out.println("Scegli il macchinista");
        List<Lavoratore> macchinisti = lavoratoreController.getLavoratore(1, "NULL");

        for (Lavoratore macchinista_ : macchinisti) {
            System.out.println(macchinista_.getCodiceFiscale());
        }

        String macchinista = reader.readLine();
        corsa.setCFLav1(macchinista);

        System.out.println("Scegli il capotreno");
        List<Lavoratore> capotreni = lavoratoreController.getLavoratore(0, "NULL");
        for (Lavoratore capotreno : capotreni) {
            System.out.println(capotreno.getCodiceFiscale());
        }

        String capotreno = reader.readLine();
        corsa.setCFLav2(capotreno);

        java.sql.Date dataAcquisto = null;
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            System.out.println("Inserisci la data in cui dovrà essere fatta la corsa: [yyyy-mm-dd]");
            Date date = dateFormat.parse(reader.readLine());
            dataAcquisto = new java.sql.Date(date.getTime());
            corsa.setDataCorsa(dataAcquisto);
        } catch (ParseException e) {
            System.out.println("Errore nell'inserimento della data");
            e.printStackTrace();
            System.exit(1);
        }

        List<String> fermateSelezionate = tratteMap.get(sceltaTratta);

        // Ciclo per inserire gli orari delle fermate
        int a = 1;
        for (String fermata : fermateSelezionate) {
            if (a == 1) {
                // Prima fermata
                System.out.printf("Inserisci l'orario di partenza della fermata numero %d, nome fermata: %s%n", a, fermata);
                String orarioPartenza = reader.readLine();
                try {
                    if (orarioPartenza.matches("\\d{2}:\\d{2}")) {
                        // Assegna l'orario di partenza
                        corsa.setOrari(orarioPartenza);
                    } else {
                        throw new IllegalArgumentException("Formato orario non valido.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Errore nell'inserimento dell'orario. Usa il formato hh:mm.");
                    e.printStackTrace();
                }
            } else if (a == fermateSelezionate.size()) {
                // Ultima fermata
                System.out.printf("Inserisci l'orario di arrivo della fermata numero %d, nome fermata: %s%n", a, fermata);
                String orarioArrivo = reader.readLine();
                try {
                    if (orarioArrivo.matches("\\d{2}:\\d{2}")) {
                        // Assegna l'orario di arrivo
                        corsa.setOrari(orarioArrivo);
                    } else {
                        throw new IllegalArgumentException("Formato orario non valido.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Errore nell'inserimento dell'orario. Usa il formato hh:mm.");
                    e.printStackTrace();
                }
            } else {
                // Fermate intermedie
                System.out.printf("Inserisci l'orario di partenza della fermata numero %d, nome fermata: %s%n", a, fermata);
                String orarioPartenza = reader.readLine();
                System.out.printf("Inserisci l'orario di arrivo della fermata numero %d, nome fermata: %s%n", a, fermata);
                String orarioArrivo = reader.readLine();
                try {
                    if (orarioPartenza.matches("\\d{2}:\\d{2}") && orarioArrivo.matches("\\d{2}:\\d{2}")) {
                        // Concatena l'orario di partenza e arrivo con il formato richiesto
                        String orarioCompleto = orarioPartenza + "-" + orarioArrivo;

                        corsa.setOrari(orarioCompleto);
                    } else {
                        throw new IllegalArgumentException("Formato orario non valido.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Errore nell'inserimento dell'orario. Usa il formato hh:mm.");
                    e.printStackTrace();
                }
            }
            a++;
        }


        return corsa;
    }



    public static Treni getTrenoInfo() throws IOException, DAOException {
        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Treni treno = new Treni();


        System.out.println("");
        System.out.println("Inserisci la matricola del Treno da aggiungere: ");
        treno.setMatricola(reader.readLine());
        java.sql.Date dataAcquisto = null;
        try{
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            System.out.println("Inserisci la data di acquisto del treno: [yyyy-mm-dd]");
            Date date = dateFormat.parse(reader.readLine());
            dataAcquisto = new java.sql.Date(date.getTime());
            treno.setdataDiAcquisto(dataAcquisto);
        } catch (ParseException e) {
            System.out.println("Errore nell'inserimento della data di acquisto del treno");
            e.printStackTrace();
            System.exit(1);
        }

      return treno;
    }

    public static Locomotrici getLocomotriciInfo() throws IOException, DAOException {

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Locomotrici locomotrici = new Locomotrici();

        //controllare bene se l'id va messo
        System.out.println("");
        System.out.println("Inserisci l'id della locomotrice da aggiungere: ");
        locomotrici.setId(Integer.parseInt(reader.readLine()));
        System.out.println("Inserisci la marca: ");
        locomotrici.setMarca(reader.readLine());

        System.out.println("Inserisci il modello: ");
        locomotrici.setModello(reader.readLine());


        return locomotrici;
    }

    public static Vagone getVagoniInfo() throws IOException, DAOException {

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Vagone vagone = new Vagone();

        System.out.println("");
        System.out.println("Inserisci l id del vagone: ");
        vagone.setId(Integer.parseInt(reader.readLine()));

        //controllare bene se l'id va messo
        System.out.println("");
        System.out.println("Inserisci la marca del vagone da aggiungere: ");
        vagone.setMarca(reader.readLine());
        System.out.println("Inserisci la classe: ");
        vagone.setClasse(Integer.parseInt(reader.readLine()));

        System.out.println("Inserisci il modello: ");
        vagone.setModello(reader.readLine());

        System.out.println("Inserisci il numero massimo di Passeggeri: ");
        vagone.setMaxPasseggeri(Integer.parseInt(reader.readLine()));


        return vagone;
    }

    public static Fermate getFermateInfo() throws IOException, DAOException, ParseException {

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Fermate fermate = new Fermate();

        System.out.println("");
        System.out.println("Inserisci il nome della stazione : ");
        fermate.setStazione(reader.readLine());

        //controllare bene se l'id va messo
        System.out.println("");
        System.out.println("Inserisci la citta dove si trova la stazione: ");
        fermate.setCitta(reader.readLine());
        System.out.println("Inserisci la provincia dove si trova la stazione: ");
        fermate.setProvincia(reader.readLine());


        return fermate;
    }




    public static Lavoratore getMacchinistaInfo() throws DAOException, IOException {


        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Lavoratore lavoratore = new Lavoratore();

        ///////////////////Macchinista

        LavoratoreController lavoratoreController = new LavoratoreController();

        System.out.println("Inserisci il CF del macchinista disponibile da associare a questo treno tra quelli disponibili: ");


        List<Lavoratore> macchinisti = lavoratoreController.getLavoratore(1,null);


        for (Lavoratore macchinista : macchinisti) {
            System.out.println(macchinista.getCodiceFiscale());
        }

        boolean codiceFiscaleValidoM = false;
        String codiceFiscaleInseritoM = null;


        while (!codiceFiscaleValidoM) {

            codiceFiscaleInseritoM = reader.readLine();


            for (Lavoratore macchinista : macchinisti) {
                if (codiceFiscaleInseritoM.equals(macchinista.getCodiceFiscale())) {
                    System.out.println("codice fiscale inserito correttamente");
                    lavoratore.setCodiceFiscale(codiceFiscaleInseritoM);
                    codiceFiscaleValidoM = true;
                    break;
                }
            }


            if (!codiceFiscaleValidoM) {
                System.out.println("Il codice fiscale inserito non è valido. Inseriscilo di nuovo: ");
            }
        }

        return lavoratore;
    }

    public static Treni getTrenoMatricola()  throws DAOException, IOException{

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il treno a cui associarla tra quelli disponibili: ");
        GestoreController gestoreController = new GestoreController();
        List<Treni> treni =gestoreController.getTreniInfo();
        Treni _treno_ = new Treni();


        for (Treni treni_ : treni) {
            System.out.println(treni_.getMatricola());
        }

        boolean matricola = false;
        String matricolaInseritoM = null;


        while (!matricola) {

            matricolaInseritoM = reader.readLine();


            for (Treni treni_ : treni) {
                if (matricolaInseritoM.equals(treni_.getMatricola())) {
                    System.out.println("matricola inserito correttamente");
                    _treno_.setMatricola(matricolaInseritoM);
                    matricola = true;
                    break;
                }
            }


            if (!matricola) {
                System.out.println("Il codice fiscale inserito non è valido. Inseriscilo di nuovo: ");
            }
        }

        return _treno_;
    }


    public static List<Fermate> newTratta() throws DAOException, IOException {

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Fermate fermata = new Fermate();
        List<Fermate> fermate= new ArrayList<>();
        System.out.println("Benvenuto in registra una nuova tratta: ");
        System.out.println("Scegli quale fermate coinvolgere nella nuova tratta nell'ordine che verranno percorse");
        GestoreController gestoreController = new GestoreController();
        fermate=gestoreController.visualizzaTratta();

        int counter = 1;  // Inizializza un contatore

        for (Fermate ferm : fermate) {
            System.out.println(counter + ") " + ferm.getStazione() + "," + ferm.getCitta() + "," + ferm.getProvincia());
            counter++;  // Incrementa il contatore
        }

        System.out.println("Quante stazioni vuoi inserire?");
        int numero = Integer.parseInt(reader.readLine());
        List<Fermate> nuovaTratta = new ArrayList<>();

        for (int i = 1; i <= numero; i++) {
            System.out.printf("Inserisci il nome della stazione numero %d: ", i);
            String stazione = reader.readLine();

            boolean stazioneValida = false;
            for (Fermate ferm : fermate) {
                if (ferm.getStazione().equalsIgnoreCase(stazione)) {
                    stazioneValida = true;
                    Fermate nuovaFermata = new Fermate();
                    nuovaFermata.setStazione(ferm.getStazione());
                    nuovaFermata.setCitta(ferm.getCitta());
                    nuovaFermata.setProvincia(ferm.getProvincia());
                    nuovaTratta.add(nuovaFermata);
                    break;
                }
            }

            if (!stazioneValida) {
                System.out.println("Errore: La stazione inserita non è valida. Per favore inserisci una stazione valida.");
                i--; // Decrementa il contatore per permettere un nuovo tentativo di inserimento
            }
        }


        return nuovaTratta;

    }



    public static Lavoratore getCapotrenoInfo() throws DAOException, IOException {
        //////Capotreno

        LavoratoreController lavoratoreController = new LavoratoreController();

        Scanner input = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Lavoratore lavoratore = new Lavoratore();


        System.out.println("Inserisci il CF del capotreno disponibile da associare a questo treno tra quelli disponibili: ");


        List<Lavoratore> capotreni = lavoratoreController.getLavoratore(0,null);


        for (Lavoratore capotreno : capotreni) {
            System.out.println(capotreno.getCodiceFiscale());
        }

        boolean codiceFiscaleValido = false;
        String codiceFiscaleInserito = null;


        while (!codiceFiscaleValido) {

            codiceFiscaleInserito = reader.readLine();


            for (Lavoratore capotreno : capotreni) {
                if (codiceFiscaleInserito.equals(capotreno.getCodiceFiscale())) {
                    System.out.println("codice fiscale inserito correttamente");
                    lavoratore.setCodiceFiscale(codiceFiscaleInserito);
                    codiceFiscaleValido = true;
                    break;
                }
            }


            if (!codiceFiscaleValido) {
                System.out.println("Il codice fiscale inserito non è valido. Inseriscilo di nuovo: ");
            }
        }


        return lavoratore;

    }

    public static void exit(){
        System.out.println("");
        System.out.println("A presto!");
    }
}



