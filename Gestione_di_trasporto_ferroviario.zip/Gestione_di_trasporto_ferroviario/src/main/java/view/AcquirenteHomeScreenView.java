package view;

import controller.AcquirenteController;
import controller.GestoreController;
import exception.DAOException;
import model.domain.*;


import javax.xml.crypto.Data;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class AcquirenteHomeScreenView {
    private static final Pattern TIME_PATTERN = Pattern.compile("^([01]?\\d|2[0-3]):[0-5]\\d$");

    public static int showHomeScreen() throws IOException {

        System.out.println("sei loggato come acquirente scegli cosa vuoi fare");

        int choise;
        System.out.println("");
        System.out.println("Benvenuto nella tua home screen!");
        System.out.println("Cosa vuoi fare?");
        System.out.println("1) Visualizza le tue prenotazioni");
        System.out.println("2) Acquistare una prenotazione ");
        System.out.println("3) Esci");
        System.out.println("");
        Scanner input = new Scanner(System.in);

        while(true){

            System.out.println("Inserisci il codice: ");
            choise = input.nextInt();
            if(choise >= 1 && choise <= 3){
                break;
            }
            System.out.println("Codice non valido");
        }

        return choise;
    }

    public void visualizzaPrenotaioni(List<Prenotazione> prenotazioni)  {



        System.out.println("Queste sono le tue prenotazioni");
        System.out.println("-------------------------------------------------------------");

        for (Prenotazione prenotazione : prenotazioni) {
            String output = String.format("Treno: %s, Vagone: %s, Posto: %s, Data: %s, Partenza: %s",
                    prenotazione.getTreno(),
                    prenotazione.getVagone(),
                    prenotazione.getPostoTreno(),
                    prenotazione.getData(),
                    prenotazione.getPartenza());
            System.out.println(output);
        }





    }



    public static void exit(){
        System.out.println("");
        System.out.println("A presto!");
    }

    public static Corsa acquistaPrenotazione() throws DAOException, IOException {
        System.out.println("Benvenuto in acquista una prenotazione");
        System.out.println("-------------------------------------");
        System.out.println("Scegli la tratta da compiere");
        Corsa corsa = new Corsa();

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        GestoreController gestoreController = new GestoreController();
        List<Tratta> tratte = gestoreController.getTratteInfo();
        Map<Integer, List<String>> tratteMap = new LinkedHashMap<>();
        for (Tratta tratta_ : tratte) {
            tratteMap.computeIfAbsent(tratta_.getId(), k -> new ArrayList<>()).add(tratta_.getStazione());
        }

        int index = 1;
        for (Map.Entry<Integer, List<String>> entry : tratteMap.entrySet()) {
            System.out.printf("%d) %s%n", index, String.join(",", entry.getValue()));
            index++;
        }

        int sceltaTratta = Integer.parseInt(reader.readLine());
        corsa.setIdTratta(sceltaTratta);



        java.sql.Date dataAcquisto = null;
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            System.out.println("Inserisci la data in cui dovrà essere fatta la corsa: [yyyy-mm-dd]");
            Date date = dateFormat.parse(reader.readLine());
            dataAcquisto = new java.sql.Date(date.getTime());
            corsa.setDataCorsa(dataAcquisto);
        } catch (ParseException e) {
            System.out.println("Errore nell'inserimento della data");
            e.printStackTrace();
            System.exit(1);
        }



        return corsa;
    }


    public static Time visualizzaOrari(List<Orari> orari) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int i = 0;
        if (orari == null || orari.isEmpty()) {
            System.out.println("Nessuna corsa registrata per questa tratta o questa data, cambiare data oppure tratta.");
            return null;  // O potresti lanciare un'eccezione
        }

        for (Orari orari_ : orari) {
            System.out.printf("%d) %s - %s%n", i+1, orari_.getOrarioPartenza().toString(), orari_.getOrarioArrivo().toString());
            i++;
        }

        String orarioPartenzaStr;
        while (true) {
            System.out.println("Scegli l'orario in cui partire (formato HH:mm):");
            orarioPartenzaStr = reader.readLine();

            if (isOrarioValido(orarioPartenzaStr)) {
                System.out.println("Orario di partenza scelto: " + orarioPartenzaStr);
                break;
            } else {
                System.out.println("Formato orario non valido. Riprova.");
            }
        }

        return convertToTime(orarioPartenzaStr);
    }

    public static Time convertToTime(String orario) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        try {
            long ms = sdf.parse(orario).getTime();
            return new Time(ms);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Formato orario non valido: " + orario, e);
        }
    }

    public static boolean isOrarioValido(String orario) {
        if (orario == null) {
            return false;
        }

        if (!TIME_PATTERN.matcher(orario).matches()) {
            return false;
        }

        // Controllo aggiuntivo per verificare che l'orario sia effettivamente valido
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setLenient(false);
        try {
            sdf.parse(orario);
        } catch (ParseException e) {
            return false;
        }

        return true;
    }
}













