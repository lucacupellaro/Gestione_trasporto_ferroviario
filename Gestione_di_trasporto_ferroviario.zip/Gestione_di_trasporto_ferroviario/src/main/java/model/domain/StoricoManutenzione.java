package model.domain;

import java.util.Date;

public class StoricoManutenzione {
    private String manutenzione;
    private Date data;
    private String treno;

    public StoricoManutenzione() {}

    public StoricoManutenzione(String manutenzione, Date data,String treno){
        this.manutenzione=manutenzione;
        this.data=data;
    }

    public java.sql.Date getData() {
        return (java.sql.Date) data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getManutenzione() {
        return manutenzione;
    }

    public void setManutenzione(String manutenzione) {
        this.manutenzione = manutenzione;
    }

    public String getTreno() {
        return treno;
    }

    public void setTreno(String treno) {
        this.treno = treno;
    }

}
