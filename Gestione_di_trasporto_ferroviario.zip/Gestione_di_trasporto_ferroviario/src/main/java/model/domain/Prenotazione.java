package model.domain;

import java.sql.Date;
import java.sql.Time;

public class Prenotazione {

    private int postoTreno;
    private String treno;
    private String vagone;
    private int tratta;
    private Time partenza;
    private Date data;
    private String CF;


    public Prenotazione(){
        this.treno = treno;
        this.vagone = vagone;
        this.data = data;
        this.postoTreno = postoTreno;
        this.partenza = partenza;
    }

    public Prenotazione(String CF, Date data,Time partenza, int tratta){
        this.tratta = tratta;
        this.partenza = partenza;
        this.CF = CF;
        this.data=data;
    }

    public Date getData() {
        return  data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getCF() {
        return CF;
    }

    public void setCF(String CF) {
        this.CF = CF;
    }

    public Time getPartenza() {
        return partenza;
    }

    public void setPartenza(Time partenza) {
        this.partenza = partenza;
    }

    public void setTratta(int tratta) {
        this.tratta = tratta;
    }

    public int getTratta() {
        return tratta;
    }

    public String getVagone() {
        return vagone;
    }

    public void setVagone(String vagone) {
        this.vagone = vagone;
    }

    public int getPostoTreno() {
        return postoTreno;
    }

    public void setPostoTreno(int postoTreno) {
        this.postoTreno = postoTreno;
    }

    public void setTreno(String treno) {
        this.treno = treno;
    }

    public String getTreno() {
        return treno;
    }
}






