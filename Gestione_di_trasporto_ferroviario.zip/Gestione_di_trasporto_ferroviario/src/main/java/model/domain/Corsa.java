package model.domain;
import java.sql.Date;
import java.util.ArrayList;

import java.util.List;

public class Corsa {
    private int idCorsa;
    private Date dataCorsa;
    private int  idTratta;
    private String matricolaTreno;
    private String CFLav1;
    private String CFLav2;
    private List<String> orari;



    public Corsa(int idCorsa, Date dataCorsa, int idTratta,String matricolaTreno,String CFLav2, String CFLav1){
        this.idCorsa=idCorsa;
        this.dataCorsa=dataCorsa;
        this.idTratta=idTratta;
        this.matricolaTreno=matricolaTreno;
        this.CFLav1=CFLav1;
        this.CFLav2=CFLav2;
        this.orari = new ArrayList<>();

    }

    public Corsa(){
        this.orari=new ArrayList<>();
    }

    public void setOrari(String orario){

        this.orari.add(orario);


    }

    public <List>String getOrari(){
        return String.valueOf(orari);
    }

    public int getCorsa(){
        return idCorsa;
    }

    public void setIdCorsa(int idCorsa){
        this.idCorsa=idCorsa;
    }

    public void setDataCorsa(Date dataCorsa){
        this.dataCorsa=dataCorsa;
    }

    public Date getDataCorsa(){
        return dataCorsa;
    }

    public void setIdTratta(int idTratta){
        this.idTratta=idTratta;
    }

    public int getIdTratta(){
        return idTratta;
    }

    public void setmatricolaTreno(String matricolaTreno){
        this.matricolaTreno=matricolaTreno;
    }

    public String getMatricolaTreno(){
        return matricolaTreno;
    }

    public void setCFLav1(String CFLav1){
        this.CFLav1=CFLav1;
    }

    public void setCFLav2(String CFLav2){
        this.CFLav2=CFLav2;
    }

    public String getICFLav1(){
        return CFLav1;
    }

    public String getICFLav2(){
        return CFLav2;
    }



}
