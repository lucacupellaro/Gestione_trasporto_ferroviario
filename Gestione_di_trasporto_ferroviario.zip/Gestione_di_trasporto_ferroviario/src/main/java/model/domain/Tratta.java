package model.domain;

import java.util.ArrayList;
import java.util.List;

public class Tratta {

    private int idTratta;
    private int numeroFermata;
    private String stazione;

    private List<Fermate> fermate;

    public Tratta() {
        fermate=new ArrayList<>();
    }

    public Tratta(int idTratta, int numeroFermata, String stazione){
        this.idTratta=idTratta;
        this.numeroFermata=numeroFermata;
        this.stazione=stazione;
    }

    public int getId() {
        return idTratta;
    }

    public void setId(int idTratta) {
        this.idTratta = idTratta;
    }

    public void setFermate( List<Fermate> fermate) {
        this.fermate = fermate;
    }

    public List<Fermate> getFermate() {
        return fermate;
    }

    public static String formattaFermate(List<Fermate> fermate) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < fermate.size(); i++) {
            sb.append(fermate.get(i).getStazione());
            if (i < fermate.size() - 1) {
                sb.append(",");
            }
        }

        return sb.toString();
    }

    public String getStazione() {
        return stazione;
    }

    public void setStazione(String stazione) {
        this.stazione = stazione;
    }


    public int getNumeroFermata() {
        return numeroFermata;
    }

    public void setNumeroFermata(int numeroFermata) {
        this.numeroFermata = numeroFermata;
    }


}
