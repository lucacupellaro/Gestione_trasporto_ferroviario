package model.domain;

import java.sql.Time;
import java.time.LocalTime;

public class Fermate {


    private String citta;
    private String stazione;
    private String provincia;




    public Fermate (){}

    public Fermate(String citta, String stazione, String provincia){
        this.citta=citta;
        this.stazione=stazione;
        this.provincia=provincia;


    }

    public String getCitta(){
        return citta;
    }

    public void setCitta(String citta){
        this.citta=citta;
    }

    public void setStazione(String stazione){
        this.stazione=stazione;
    }

    public String getStazione(){
        return stazione;
    }

    public void setProvincia(String provincia){
        this.provincia=provincia;
    }

    public String getProvincia(){
        return provincia;
    }

}

