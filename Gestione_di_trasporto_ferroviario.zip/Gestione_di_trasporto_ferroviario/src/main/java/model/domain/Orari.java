package model.domain;
import java.sql.Date;
import java.sql.Time;


public class Orari {

    private Date dataCorsa;
    private String matricolaTreno ;
    private Time orarioPartenza;
    private Time orarioArrivo;


    public Orari() {}

    public Orari(Time orarioPartenza, Time orarioArrivo, Date dataCorsa, String matricolaTreno) {
        this.dataCorsa = dataCorsa;
        this.matricolaTreno = matricolaTreno;
        this.orarioPartenza = orarioPartenza;
        this.orarioArrivo = orarioArrivo;
    }



    public void setOrarioPartenza(Time orarioPartenza) {
        this.orarioPartenza = orarioPartenza;
    }

    public void setOrarioArrivo(Time orarioArrivo) {
        this.orarioArrivo = orarioArrivo;
    }

    public Time getOrarioArrivo() {
        return orarioArrivo;
    }

    public Time getOrarioPartenza() {
        return orarioPartenza;
    }

    public void setDataCorsa(Date dataCorsa) {
        this.dataCorsa = dataCorsa;
    }

    public Date getDataCorsa() {
        return dataCorsa;
    }

    public void setMatricolaTreno(String matricolaTreno) {
        this.matricolaTreno = matricolaTreno;
    }

    public String getMatricolaTreno() {
        return matricolaTreno;
    }


}
