package model.dao;

import exception.DAOException;
import model.domain.StoricoManutenzione;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RegistraManutenzioneProcedureDao implements GenericProcedureDAO<Boolean>{
    public static RegistraManutenzioneProcedureDao instance = null;

    private RegistraManutenzioneProcedureDao() {
    }

    public static RegistraManutenzioneProcedureDao getInstance() {
        if (instance == null) {
            instance = new RegistraManutenzioneProcedureDao();
        }

        return instance;
    }


    public Boolean execute(Object... params) throws DAOException {

        StoricoManutenzione manutenzione = (StoricoManutenzione)params[0];


        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_manutenzione(?,?,?)}");
            callableStatement.setString(1, manutenzione.getTreno());
            callableStatement.setDate(2, manutenzione.getData());
            callableStatement.setString(3, manutenzione.getManutenzione());
            callableStatement.execute();
        } catch (SQLException var5) {
            System.out.println(var5.getMessage());
            SQLException sqlException = var5;
            throw new DAOException("Errore nella registrazione della manutenzione: " + sqlException.getMessage());
        }

        return true;


    }
}
