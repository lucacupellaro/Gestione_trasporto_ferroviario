package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;
import model.domain.Locomotrici;
import model.domain.Treni;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class LocomotriceRegistrationProcedureDAO implements GenericProcedureDAO<Boolean>{
    public static LocomotriceRegistrationProcedureDAO instance = null;

    private LocomotriceRegistrationProcedureDAO() {
    }

    public static LocomotriceRegistrationProcedureDAO getInstance() {
        if (instance == null) {
            instance = new LocomotriceRegistrationProcedureDAO();
        }

        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {

        Locomotrici locomotrici = (Locomotrici) params[0];
        Treni treno = (Treni)params[1];




        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_locomotrici(?,?,?,?)}");
            callableStatement.setInt(1, locomotrici.getId());
            callableStatement.setString(2, locomotrici.getMarca());
            callableStatement.setString(3, locomotrici.getModello());
            callableStatement.setString(4, treno.getMatricola());
            callableStatement.execute();
        } catch (SQLException var5) {
            SQLException sqlException = var5;
            System.out.println(var5);

            throw new DAOException("Errore nella registrazione della locomotrice: " + sqlException.getMessage());
        }

        return true;


    }
}
