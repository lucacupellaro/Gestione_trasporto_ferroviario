package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;
import model.domain.Treni;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class TrenoRegistrationProcedureDao implements GenericProcedureDAO<Boolean>{
    public static TrenoRegistrationProcedureDao instance = null;

    private TrenoRegistrationProcedureDao() {
    }

    public static TrenoRegistrationProcedureDao getInstance() {
        if (instance == null) {
            instance = new TrenoRegistrationProcedureDao();
        }

        return instance;
    }


    public Boolean execute(Object... params) throws DAOException {

        Treni treno = (Treni)params[0];
        Lavoratore macchinista = (Lavoratore)params[1];
        Lavoratore capotreno = (Lavoratore)params[2];

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_treno(?,?,?,?)}");
            callableStatement.setString(1, treno.getMatricola());
            callableStatement.setDate(2, treno.getdataDiAcquisto());
            callableStatement.setString(3, macchinista.getCodiceFiscale());
            callableStatement.setString(4, capotreno.getCodiceFiscale());
            callableStatement.execute();
        } catch (SQLException var5) {
            SQLException sqlException = var5;
            throw new DAOException("Errore nella registrazione de treno: " + sqlException.getMessage());
        }

        return true;


    }
}
