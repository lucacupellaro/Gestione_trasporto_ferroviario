package model.dao;

import exception.DAOException;
import model.domain.Corsa;
import model.domain.Fermate;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RegistraCorseProcedureDao implements GenericProcedureDAO<Boolean>{
    public static RegistraCorseProcedureDao instance = null;

    private RegistraCorseProcedureDao() {
    }

    public static RegistraCorseProcedureDao getInstance() {
        if (instance == null) {
            instance = new RegistraCorseProcedureDao();
        }

        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Corsa corsa = (Corsa) params[0];



        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call new_registra_corsa(?,?,?,?,?,?)}");
            callableStatement.setString(1, corsa.getICFLav1());
            callableStatement.setString(2, corsa.getICFLav2());
            callableStatement.setString(3, corsa.getMatricolaTreno());
            callableStatement.setDate(4, corsa.getDataCorsa());
            callableStatement.setInt(5, corsa.getIdTratta());
            callableStatement.setString(6, corsa.getOrari());


                System.out.println(corsa.getOrari());



            callableStatement.execute();
        } catch (SQLException var5) {
            SQLException sqlException = var5;
            System.out.println(var5.getMessage());
            throw new DAOException("Errore nella registrazione della corsa: " + sqlException.getMessage());
        }

        return true;
    }
}
