package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetLavoratoriProcedureDAO {

    private static GetLavoratoriProcedureDAO instance = null;

    public GetLavoratoriProcedureDAO(){}

    public static GetLavoratoriProcedureDAO getInstance(){
        if(instance == null){
            instance = new GetLavoratoriProcedureDAO();
        }

        return instance;
    }


    public List<Lavoratore> getCapotreni() throws DAOException {

        List <Lavoratore> lavoratori = new ArrayList<Lavoratore>();

        try {

            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_lavoratori(NULL,0)}");
            boolean flag = callableStatement.execute();

            if(flag) {

                ResultSet resultSet = callableStatement.getResultSet();

                while (resultSet.next()) {

                    Lavoratore lavoratore = new Lavoratore();
                    lavoratore.setCodiceFiscale(resultSet.getString(1));
                    lavoratori.add(lavoratore);

                }


            }

        } catch (SQLException sqlException) {
            throw new DAOException("Errore in lista Lavoratori: " + sqlException.getMessage());
        }

        return lavoratori;
    }

    public List<Lavoratore> getMacchinisti() throws DAOException {

        List <Lavoratore> lavoratori = new ArrayList<Lavoratore>();

        try {

            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_lavoratori(NULL,1)}");
            boolean flag = callableStatement.execute();

            if(flag) {

                ResultSet resultSet = callableStatement.getResultSet();

                while (resultSet.next()) {

                    Lavoratore lavoratore = new Lavoratore();
                    lavoratore.setCodiceFiscale(resultSet.getString(1));
                    lavoratori.add(lavoratore);

                }


            }

        } catch (SQLException sqlException) {
            throw new DAOException("Errore in lista Lavoratori: " + sqlException.getMessage());
        }

        return lavoratori;
    }

    public List<Lavoratore> getMacchinistiTreno(String matricola) throws DAOException {

        List <Lavoratore> lavoratori = new ArrayList<Lavoratore>();

        try {

            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_lavoratori(?,?)}");
            callableStatement.setString(1, matricola);
            callableStatement.setInt(2, 2);
            boolean flag = callableStatement.execute();

            if(flag) {

                ResultSet resultSet = callableStatement.getResultSet();

                while (resultSet.next()) {
                    Lavoratore lavoratore = new Lavoratore();
                    lavoratore.setCodiceFiscale(resultSet.getString(1));
                    lavoratori.add(lavoratore);

                }


            }

        } catch (SQLException sqlException) {
            throw new DAOException("Errore in lista Lavoratori: " + sqlException.getMessage());
        }

        return lavoratori;
    }

    public List<Lavoratore> getCapotrenoTreno(String matricola) throws DAOException {

        List <Lavoratore> lavoratori = new ArrayList<Lavoratore>();

        try {

            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_lavoratori(?,?)}");
            callableStatement.setString(1, matricola);
            callableStatement.setInt(2, 3);
            boolean flag = callableStatement.execute();

            if(flag) {

                ResultSet resultSet = callableStatement.getResultSet();

                while (resultSet.next()) {
                    Lavoratore lavoratore = new Lavoratore();
                    lavoratore.setCodiceFiscale(resultSet.getString(1));
                    lavoratori.add(lavoratore);

                }


            }

        } catch (SQLException sqlException) {
            throw new DAOException("Errore in lista Lavoratori: " + sqlException.getMessage());
        }

        return lavoratori;
    }





}
