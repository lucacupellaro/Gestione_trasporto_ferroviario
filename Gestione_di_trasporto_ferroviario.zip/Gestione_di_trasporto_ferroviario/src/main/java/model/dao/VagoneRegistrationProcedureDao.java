package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;
import model.domain.Treni;
import model.domain.Vagone;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class VagoneRegistrationProcedureDao implements GenericProcedureDAO<Boolean> {

    public static VagoneRegistrationProcedureDao instance = null;

    private VagoneRegistrationProcedureDao() {
    }

    public static VagoneRegistrationProcedureDao getInstance() {
        if (instance == null) {
            instance = new VagoneRegistrationProcedureDao();
        }

        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Vagone vagone = (Vagone) params[0];
        Treni treno = (Treni) params[1];

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_vagone(?,?,?,?,?,?)}");
            callableStatement.setInt(1, vagone.getId());
            callableStatement.setString(2, vagone.getMarca());
            callableStatement.setInt(3, vagone.getClasse());
            callableStatement.setString(4, vagone.getModello());
            callableStatement.setInt(5, vagone.getMaxPasseggeri());
            callableStatement.setString(6, treno.getMatricola());
            callableStatement.execute();
        } catch (SQLException var5) {
            SQLException sqlException = var5;
            System.out.println(var5.getMessage());
            throw new DAOException("Errore nella registrazione de treno: " + sqlException.getMessage());
        }

        return true;
    }
}
