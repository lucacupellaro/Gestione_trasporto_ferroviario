package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;
import model.domain.Treni;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetTreniProcedureDAO {

    private static GetTreniProcedureDAO instance = null;

    public GetTreniProcedureDAO(){}

    public static GetTreniProcedureDAO getInstance(){
        if(instance == null){
            instance = new GetTreniProcedureDAO();
        }

        return instance;
    }


    public List<Treni> getTreni() throws DAOException {
        List<Treni> treni = new ArrayList<>();

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_treni()}");
            boolean flag = callableStatement.execute();

            if (flag) {
                ResultSet resultSet = callableStatement.getResultSet();
                while (resultSet.next()) {
                    Treni treno = new Treni();
                    treno.setMatricola(resultSet.getString(1));
                    treni.add(treno);
                }
            }

            // Chiusura delle risorse
            callableStatement.close();
            connection.close();
        } catch (SQLException sqlException) {
            throw new DAOException("Errore treni disponibili: " + sqlException.getMessage());
        }


        return treni;
    }

}
