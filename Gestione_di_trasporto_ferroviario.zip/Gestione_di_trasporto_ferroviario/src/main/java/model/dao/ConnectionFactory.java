package model.dao;

import model.domain.Role;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionFactory {
    private static Connection connection;
    private static final String PROPERTIES_FILE = "src/main/resources/db.properties";
    private static Properties properties = new Properties();

    private ConnectionFactory() {}

    static {
        try (InputStream input = new FileInputStream(PROPERTIES_FILE)) {
            properties.load(input);
            initConnection();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void initConnection() throws SQLException {
        String connectionUrl = properties.getProperty("CONNECTION_URL");
        String user = properties.getProperty("LOGIN_USER");
        String pass = properties.getProperty("LOGIN_PASS");
        connection = DriverManager.getConnection(connectionUrl, user, pass);
    }

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            initConnection();
        }
        return connection;
    }

    public static void changeRole(Role role) throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }

        try (InputStream input = new FileInputStream(PROPERTIES_FILE)) {
            Properties properties = new Properties();
            properties.load(input);

            String connectionUrl = properties.getProperty("CONNECTION_URL");
            String user = properties.getProperty(role.name() + "_USER");
            String pass = properties.getProperty(role.name() + "_PASS");

            connection = DriverManager.getConnection(connectionUrl, user, pass);
        } catch (IOException e) {
            e.printStackTrace();
            throw new SQLException("Errore durante il cambio di ruolo", e);
        }
    }
}
