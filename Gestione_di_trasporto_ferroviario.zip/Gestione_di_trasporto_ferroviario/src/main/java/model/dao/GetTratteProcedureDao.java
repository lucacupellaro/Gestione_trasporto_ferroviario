package model.dao;

import exception.DAOException;
import model.domain.Fermate;
import model.domain.Tratta;
import model.domain.Treni;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GetTratteProcedureDao {

    private static GetTratteProcedureDao instance = null;

    public GetTratteProcedureDao(){}

    public static GetTratteProcedureDao getInstance(){
        if(instance == null){
            instance = new GetTratteProcedureDao();
        }

        return instance;
    }


    public List<Tratta> getTratte() throws DAOException {

        List<Tratta> tratte = new ArrayList<>();

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_tratte()}");
            boolean flag = callableStatement.execute();

            if (flag) {
                ResultSet resultSet = callableStatement.getResultSet();
                while (resultSet.next()) {
                    Tratta tratta = new Tratta();
                    tratta.setNumeroFermata(resultSet.getInt(1));
                    tratta.setId(resultSet.getInt(2));
                    tratta.setStazione(resultSet.getString(3));
                    tratte.add(tratta);
                }
            }

            // Chiusura delle risorse
            callableStatement.close();
            connection.close();
        } catch (SQLException sqlException) {
            throw new DAOException("Errore treni disponibili: " + sqlException.getMessage());
        }


        return tratte;
    }

}

