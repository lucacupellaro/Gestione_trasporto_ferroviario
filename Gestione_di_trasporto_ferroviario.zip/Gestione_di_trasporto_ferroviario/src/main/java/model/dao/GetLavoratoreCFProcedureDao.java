package model.dao;

import exception.DAOException;
import model.domain.Acquirente;
import model.domain.Lavoratore;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetLavoratoreCFProcedureDao {
    private static GetLavoratoreCFProcedureDao instance = null;

    public GetLavoratoreCFProcedureDao() {
    }

    public static GetLavoratoreCFProcedureDao getInstance() {
        if (instance == null) {
            instance = new GetLavoratoreCFProcedureDao();
        }

        return instance;
    }

    public Lavoratore execute(Object... params) throws DAOException {
        String username = (String) params[0];

        Lavoratore lavoratore = null;
        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call CF_Lavoratori(?)}");
            callableStatement.setString(1, username); // Imposta il valore del parametro
            boolean flag = callableStatement.execute();

            if (flag) {
                ResultSet resultSet = callableStatement.getResultSet();
                while (resultSet.next()) {
                    lavoratore = new Lavoratore();
                    lavoratore.setCodiceFiscale(resultSet.getString(1));
                }
            }
        } catch (SQLException sqlException) {
            throw new DAOException("Errore nella ricerca del CF del lavoratore : " + sqlException.getMessage());
        }
        return lavoratore;
    }

}
