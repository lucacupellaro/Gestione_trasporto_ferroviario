package model.dao;

import exception.DAOException;
import model.domain.Orari;
import model.domain.Prenotazione;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetPrenotazioneProcedureDao {
    private static GetPrenotazioneProcedureDao instance = null;

    public GetPrenotazioneProcedureDao(){}

    public static GetPrenotazioneProcedureDao getInstance(){
        if(instance == null){
            instance = new GetPrenotazioneProcedureDao();
        }

        return instance;
    }

    public List<Prenotazione> getPrenotazione(String Cf) throws DAOException {

        List<Prenotazione> prenotazioni = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             CallableStatement callableStatement = connection.prepareCall("{call visualizza_prenotazione(?)}")) {
            callableStatement.setString(1, Cf);

            boolean flag = callableStatement.execute();

            if (flag) {
                try (ResultSet resultSet = callableStatement.getResultSet()) {
                    while (resultSet.next()) {
                        Prenotazione prenotazione = new Prenotazione();
                        prenotazione.setTreno(resultSet.getString(1));
                        prenotazione.setVagone(resultSet.getString(2));
                        prenotazione.setData(resultSet.getDate(3));
                        prenotazione.setPostoTreno(resultSet.getInt(4));
                        prenotazione.setPartenza(resultSet.getTime(5));

                        prenotazioni.add(prenotazione);
                    }
                }
            }




        } catch (SQLException sqlException) {
            throw new DAOException("Errore nel caricamento degli orari: " + sqlException.getMessage());
        }

        return prenotazioni;
    }
}
