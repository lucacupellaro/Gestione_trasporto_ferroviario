package model.dao;

import exception.DAOException;
import model.domain.Orari;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GetOrariProcedureDao {
    private static GetOrariProcedureDao instance = null;

    public GetOrariProcedureDao(){}

    public static GetOrariProcedureDao getInstance(){
        if(instance == null){
            instance = new GetOrariProcedureDao();
        }

        return instance;
    }

    public List<Orari> getOrari(Date data, int idTratta) throws DAOException {

        List<Orari> orari = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             CallableStatement callableStatement = connection.prepareCall("{call visualizza_orari(?,?)}")) {
            callableStatement.setDate(1, new java.sql.Date(data.getTime()));
            callableStatement.setInt(2, idTratta);

            boolean flag = callableStatement.execute();

            if (flag) {
                try (ResultSet resultSet = callableStatement.getResultSet()) {
                    while (resultSet.next()) {
                        Orari orario_ = new Orari();
                        orario_.setOrarioArrivo(resultSet.getTime(5));
                        orario_.setOrarioPartenza(resultSet.getTime(4));
                        orari.add(orario_);
                    }
                }
            }



        } catch (SQLException sqlException) {
            throw new DAOException("Errore nel caricamento degli orari: " + sqlException.getMessage());
        }

        return orari;
    }
}
