package model.dao;

import exception.DAOException;
import model.domain.Fermate;
import model.domain.Tratta;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class GetFermateProcedureDao {
    private static GetFermateProcedureDao instance = null;

    public GetFermateProcedureDao(){}

    public static GetFermateProcedureDao getInstance(){
        if(instance == null){
            instance = new GetFermateProcedureDao();
        }

        return instance;
    }


    public List<Fermate> getFermate() throws DAOException {

        List<Fermate> fermate=new ArrayList<>();
        Tratta tratta=new Tratta();

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call visualizza_fermate()}");
            boolean flag = callableStatement.execute();


            if (flag) {
                ResultSet resultSet = callableStatement.getResultSet();
                while (resultSet.next()) {
                    Fermate fermateObj=new Fermate();

                    fermateObj.setStazione(resultSet.getString(1));
                    fermateObj.setCitta(resultSet.getString(2));
                    fermateObj.setProvincia(resultSet.getString(3));

                    fermate.add(fermateObj);



                }
                tratta.setFermate(fermate);
            }

        } catch (SQLException sqlException) {
            throw new DAOException("Errore nel caricamento delle fermate: " + sqlException.getMessage());
        }

        return fermate;
    }
}
