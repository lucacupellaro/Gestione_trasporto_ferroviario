package model.dao;

import exception.DAOException;
import model.domain.Acquirente;
import model.domain.Credentials;
import model.domain.Lavoratore;
import model.domain.Role;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetAcquirenteCFDao {

    private static GetAcquirenteCFDao instance = null;

    public GetAcquirenteCFDao() {
    }

    public static GetAcquirenteCFDao getInstance() {
        if (instance == null) {
            instance = new GetAcquirenteCFDao();
        }

        return instance;
    }

    public Acquirente execute(Object... params) throws DAOException {
        String username = (String) params[0];

        Acquirente acquirente = null;
        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call CF_Acquirenti(?)}");
            callableStatement.setString(1, username); // Imposta il valore del parametro
            boolean flag = callableStatement.execute();

            if (flag) {
                ResultSet resultSet = callableStatement.getResultSet();
                while (resultSet.next()) {
                    acquirente = new Acquirente();
                    acquirente.setCodiceFiscale(resultSet.getString(1));
                }
            }
        } catch (SQLException sqlException) {
            throw new DAOException("Errore nella ricerca del CF dell'utente loggato : " + sqlException.getMessage());
        }
        return acquirente;
    }

}
