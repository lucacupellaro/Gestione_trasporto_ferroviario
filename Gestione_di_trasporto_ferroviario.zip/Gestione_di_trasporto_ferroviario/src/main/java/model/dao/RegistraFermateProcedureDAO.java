package model.dao;

import exception.DAOException;
import model.domain.Fermate;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RegistraFermateProcedureDAO implements GenericProcedureDAO<Boolean>{
    public static RegistraFermateProcedureDAO instance = null;

    private RegistraFermateProcedureDAO() {
    }

    public static RegistraFermateProcedureDAO getInstance() {
        if (instance == null) {
            instance = new RegistraFermateProcedureDAO();
        }

        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Fermate fermate = (Fermate) params[0];

        System.out.println(fermate.getStazione());

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_Fermate(?,?,?)}");
            callableStatement.setString(1, fermate.getStazione());
            callableStatement.setString(2, fermate.getCitta());
            callableStatement.setString(3, fermate.getProvincia());
            callableStatement.execute();
        } catch (SQLException var5) {
            SQLException sqlException = var5;
            System.out.println(var5.getMessage());
            throw new DAOException("Errore nella registrazione della fermata: " + sqlException.getMessage());
        }

        return true;
    }
}
