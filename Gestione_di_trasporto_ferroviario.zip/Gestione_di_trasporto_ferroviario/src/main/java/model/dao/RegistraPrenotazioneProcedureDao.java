package model.dao;

import controller.LoginController;
import exception.DAOException;
import model.domain.Prenotazione;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RegistraPrenotazioneProcedureDao implements GenericProcedureDAO<Boolean> {
    private static RegistraPrenotazioneProcedureDao instance = null;

    private RegistraPrenotazioneProcedureDao() {
    }

    public static RegistraPrenotazioneProcedureDao getInstance() {
        if (instance == null) {
            instance = new RegistraPrenotazioneProcedureDao();
        }
        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Prenotazione prenotazione = (Prenotazione) params[0];
        Connection connection = null;
        CallableStatement callableStatement = null;

        try {
            connection = ConnectionFactory.getConnection();
            callableStatement = connection.prepareCall("{call registra_prenotazione2(?,?,?,?)}");

            callableStatement.setInt(1, prenotazione.getTratta());
            callableStatement.setTime(2, prenotazione.getPartenza());
            callableStatement.setDate(3, prenotazione.getData());
            callableStatement.setString(4, prenotazione.getCF());

            callableStatement.execute();

        } catch (SQLException sqlException) {
            System.out.println(sqlException.getMessage());
            throw new DAOException("Errore nella registrazione della prenotazione: " + sqlException.getMessage());
        } finally {
            try {
                if (callableStatement != null) callableStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException sqlException) {
                System.out.println("Errore nella chiusura delle risorse: " + sqlException.getMessage());
            }
        }
        return true;
    }
}
