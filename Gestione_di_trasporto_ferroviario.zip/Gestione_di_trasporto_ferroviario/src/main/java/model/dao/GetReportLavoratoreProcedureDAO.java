package model.dao;

import exception.DAOException;
import model.domain.Orari;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GetReportLavoratoreProcedureDAO {
    private static GetOrariProcedureDao instance = null;

    public GetReportLavoratoreProcedureDAO(){}

    public static GetOrariProcedureDao getInstance(){
        if(instance == null){
            instance = new GetOrariProcedureDao();
        }

        return instance;
    }

    public List<Orari> getReport(String Cf) throws DAOException {

        List<Orari> orari = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             CallableStatement callableStatement = connection.prepareCall("{call report_turni(?)}")) {
            callableStatement.setString(1, Cf);

            boolean flag = callableStatement.execute();

            if (flag) {
                try (ResultSet resultSet = callableStatement.getResultSet()) {
                    while (resultSet.next()) {
                        Orari orario_ = new Orari();
                        orario_.setDataCorsa(resultSet.getDate(2));
                        orario_.setMatricolaTreno(resultSet.getString(3));
                        orario_.setOrarioPartenza(resultSet.getTime(4));
                        orario_.setOrarioArrivo(resultSet.getTime(5));

                        orari.add(orario_);
                    }
                }
            }




        } catch (SQLException sqlException) {
            throw new DAOException("Errore nel caricamento degli orari: " + sqlException.getMessage());
        }

        return orari;
    }
}
