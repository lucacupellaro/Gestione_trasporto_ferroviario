package model.dao;

import exception.DAOException;
import model.domain.Fermate;
import model.domain.Prenotazione;
import model.domain.Tratta;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RegistraTrattaProcedureDao implements GenericProcedureDAO<Boolean> {
    public static RegistraTrattaProcedureDao instance = null;

    public RegistraTrattaProcedureDao() {
    }

    public static RegistraTrattaProcedureDao getInstance() {
        if (instance == null) {
            instance = new RegistraTrattaProcedureDao();
        }

        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Tratta tratta = (Tratta) params[0];





        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registra_Tratta(?)}");

            callableStatement.setString(1, tratta.formattaFermate(tratta.getFermate()));

            callableStatement.execute();

        } catch (SQLException var5) {
            SQLException sqlException = var5;
            System.out.println(var5.getMessage());
            throw new DAOException("Errore nella registrazione della nuova Tratta: " + sqlException.getMessage());
        }

        return true;
    }
}
